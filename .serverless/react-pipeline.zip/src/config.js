export default {
  cognito: {
    USER_POOL_ID: "us-east-1_54XZ88sE0",
    APP_CLIENT_ID: "26ikoaks67o10o179gjv6humdd"
  }
};
