import React, { Component } from "react";
import "./Home.css";

export default class Home extends Component {
  render() {
    return (
      <div className="Home">
        <div className="lander">
          <h1>React</h1>
          <p>This is the Home Page</p>
        </div>
      </div>
    );
  }
}
