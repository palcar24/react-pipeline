export default {
  cognito: {
    USER_POOL_ID: "ENTER_YOUR_USER_POOL_ID_HERE",
    APP_CLIENT_ID: "ENTER_YOUR_APP_CLIENT_ID_HERE"
  }
};
